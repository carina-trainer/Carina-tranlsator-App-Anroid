package com.example.emberatraductor;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface EmberaTranslate {
    // <server>:https://carinatrainer.herokuapp.com/
    // @POST("<server>/prediction/${this.idDataset}/${this.schema}")

    // prediction/62c2d5586c531c1e072620b8/Embera_espanol_82
    //{ body:{ query:'kua', id_document:62c2d10e6c531c1e0725e4f4 }}

    // prediction/62c2d1996c531c1e0725e5b3/Espanol_embera_82
    // { body:{ query:'hola', id_document:62c2d14b6c531c1e0725e550 }}
    // @POST("prediction/62c2d1996c531c1e0725e5b3/Espanol_embera_82")
    // <Words>
    // Call getPrediction(@Body Words words);

    /*
    @GET("posts")
    Call <List<Post>> getPosts(
            @Query("userId") Integer[] userId,
            @Query("_sort") String sort,
            @Query("_order") String order
    );

    @GET("posts")
    Call <List<Post>> getPosts(@QueryMap Map<String, String> parameters);
    */

}
