package com.example.emberatraductor;

public class EmberaEspanol {
}
