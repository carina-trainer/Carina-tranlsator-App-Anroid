package com.example.emberatranslator;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface EmberappApi {

    @POST("/endpoint/prediction/")
    Call<ResponseApi> PostData(@Body Translate translate);
    // Call<Translate> generatePrediction(@Path("name") String name, @Body String body);
}
