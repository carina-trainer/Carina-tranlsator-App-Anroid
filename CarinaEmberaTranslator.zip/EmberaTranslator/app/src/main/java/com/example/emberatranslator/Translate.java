package com.example.emberatranslator;
/*
* https://carinatrainer.herokuapp.com/dataset/62c2d14b6c531c1e0725e550/Espanol_embera_82
* ps_corpus_5c542de5-ccdc-4ccb-b7ec-a444268ad5b1.csv
* 7a8b8499-22d4-4684-aae2-5ca218e759c4
* Flag: Espanol_Embera
* */

/*
* https://carinatrainer.herokuapp.com/dataset/62c2d10e6c531c1e0725e4f4/Embera_espanol_82
* ps_corpus_85597780-1775-42b0-98e5-2f0e4709cc33.csv
* 152549a1-6a02-4403-b54f-555f37e3dd8d
* * Flag Embera_Espanol
* */

public class Translate {
    private String name;
    private String speach;

    public Translate(String name, String speach) {
        this.name = name;
        this.speach = speach;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSpeach(String speach) {
        this.speach = speach;
    }

    public String getName() {
        return name;
    }

    public String getSpeach() {
        return speach;
    }
}
