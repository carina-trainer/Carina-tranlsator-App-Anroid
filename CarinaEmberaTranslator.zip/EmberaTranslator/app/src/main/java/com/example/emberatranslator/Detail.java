package com.example.emberatranslator;

public class Detail {
    private String code;
    private String target;
    private String source;
    private String _id;
    public String __v;

    public Detail(String code, String target, String source, String _id) {
        this.code = code;
        this.target = target;
        this.source = source;
        this._id = _id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }
}
