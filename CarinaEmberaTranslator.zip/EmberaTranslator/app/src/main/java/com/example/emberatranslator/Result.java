package com.example.emberatranslator;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Result {
    private  List prediction;
    private  List<Detail> detail;

    public Result(List prediction, List<Detail> detail) {
        this.prediction = prediction;
        this.detail = detail;
    }

    public List getPrediction() {
        return prediction;
    }

    public void setPrediction(List prediction) {
        this.prediction = prediction;
    }

    public List<Detail> getDetail() {
        return detail;
    }

    public void setDetail(List<Detail> detail) {
        this.detail = detail;
    }
}
